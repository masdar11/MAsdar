# Masdar – Einnahmen & Ausgaben

Diese Version ist für **GitHub Pages** vorbereitet. Die HTML-App liegt als `index.html` im Projektstamm.

## Veröffentlichung über GitHub Pages

1. Melde dich bei https://github.com an.
2. Erstelle ein neues Repository, z. B. `masdar-einnahmen-ausgaben`.
3. Lade `index.html` und `README.md` in das Repository hoch (Add file → Upload files).
4. Öffne im Repository **Settings → Pages**.
5. Unter **Build and deployment** wähle **Deploy from a branch**.
6. Wähle den Branch `main` und den Ordner `/ (root)`, dann **Save**.
7. Warte, bis GitHub Pages die Website veröffentlicht. Die Adresse wird dort angezeigt.

## Wichtige Hinweise vor der Veröffentlichung

- GitHub Pages veröffentlicht die HTML-Datei öffentlich. Veröffentliche keine Passwörter, API-Schlüssel, privaten Zugangsdaten oder echten Finanzdaten in diesem Repository.
- Diese Veröffentlichung hostet nur die statische Oberfläche. Funktionen, die eine Laufzeitumgebung oder einen Server benötigen (z. B. `window.claude.use`), funktionieren außerhalb dieser Umgebung nicht automatisch.
- Für die Gmail-Anmeldung muss in der Google OAuth-Konfiguration die spätere GitHub-Pages-Domain als autorisierte JavaScript-Ursprungsdomain eingetragen werden. Verwende HTTPS und trage keine geheimen OAuth-Client-Secrets in die HTML-Datei ein.
- Eine direkte Anthropic/Claude-API-Anfrage aus dem Browser wäre nicht sicher, wenn dabei ein API-Schlüssel im Frontend gespeichert wird. Dafür ist ein Backend erforderlich.

## Inhalt

- `index.html` – die vorhandene Masdar-App, als Startdatei für GitHub Pages umbenannt.
